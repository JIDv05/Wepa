document.addEventListener('DOMContentLoaded', () => {
  const flashes = document.querySelectorAll('.flash-message');
  flashes.forEach(f => {
    setTimeout(() => {
      f.classList.add('opacity-0', 'translate-middle-y');
      setTimeout(() => f.remove(), 400);
    }, 3200);
  });
});
