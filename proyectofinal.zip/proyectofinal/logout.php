<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
$user = current_user();
if ($user) {
    $pdo->prepare("INSERT INTO logs (user_id, action, details) VALUES (?,?,?)")
        ->execute([$user['id'], 'logout', 'Cierre de sesión']);
}
$_SESSION = [];
session_destroy();
header('Location: login.php');
exit;
