<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('admin');

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';

// Cargar config existente
$stmt = $pdo->prepare("SELECT * FROM configuracion LIMIT 1");
$stmt->execute();
$config = $stmt->fetch(PDO::FETCH_ASSOC);

// Guardar cambios
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $sql = "UPDATE configuracion SET 
        empresa_nombre = :empresa,
        empresa_email = :email,
        empresa_telefono = :tel,
        horario_inicio = :hini,
        horario_fin = :hfin,
        dias_festivos = :festivos,
        politicas = :politicas
        WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':empresa' => $_POST['empresa_nombre'],
        ':email' => $_POST['empresa_email'],
        ':tel' => $_POST['empresa_telefono'],
        ':hini' => $_POST['horario_inicio'],
        ':hfin' => $_POST['horario_fin'],
        ':festivos' => $_POST['dias_festivos'],
        ':politicas' => $_POST['politicas'],
        ':id' => $config['id']
    ]);

    $success = "✔️ Configuración actualizada correctamente";
    
    // Recargar
    $stmt = $pdo->prepare("SELECT * FROM configuracion LIMIT 1");
    $stmt->execute();
    $config = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<div class="app-card p-4">
    <h2 class="h5 mb-3">Configuración del Sistema</h2>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST" class="mt-3">

        <!-- Empresa -->
        <h6 class="fw-bold">Información de la Empresa</h6>
        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <label class="small fw-bold">Nombre de la empresa</label>
                <input type="text" name="empresa_nombre" class="form-control" 
                    value="<?= htmlspecialchars($config['empresa_nombre'] ?? '') ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="small fw-bold">Correo</label>
                <input type="email" name="empresa_email" class="form-control" 
                    value="<?= htmlspecialchars($config['empresa_email'] ?? '') ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="small fw-bold">Teléfono</label>
                <input type="text" name="empresa_telefono" class="form-control" 
                    value="<?= htmlspecialchars($config['empresa_telefono'] ?? '') ?>">
            </div>
        </div>

        <!-- Horario -->
        <h6 class="fw-bold">Horario Laboral</h6>
        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <label class="small fw-bold">Inicio</label>
                <input type="time" name="horario_inicio" class="form-control" 
                    value="<?= htmlspecialchars($config['horario_inicio'] ?? '') ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="small fw-bold">Fin</label>
                <input type="time" name="horario_fin" class="form-control" 
                    value="<?= htmlspecialchars($config['horario_fin'] ?? '') ?>">
            </div>
        </div>

        <!-- Festivos -->
        <h6 class="fw-bold">Días Festivos</h6>
        <textarea name="dias_festivos" class="form-control mb-4" rows="3"
        placeholder="Ej: 25/12, 01/01, 15/09..."><?= htmlspecialchars($config['dias_festivos'] ?? '') ?></textarea>

        <!-- Políticas -->
        <h6 class="fw-bold">Políticas Internas</h6>
        <textarea name="politicas" class="form-control mb-4" rows="4"
        placeholder="Escribe aquí las políticas internas de la empresa"><?= htmlspecialchars($config['politicas'] ?? '') ?></textarea>

        <button class="btn btn-primary">
            <i class="fa fa-save"></i> Guardar Cambios
        </button>

    </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
