<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('admin');

$users = $pdo->query("SELECT * FROM users ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="h5 mb-0">Usuarios y Roles</h2>
    <p class="text-secondary small mb-0">Resumen de cuentas del sistema.</p>
  </div>
</div>
<div class="app-card p-3">
  <table class="table table-dark app-table table-striped small mb-0 align-middle">
    <thead>
      <tr>
        <th>Usuario</th>
        <th>Nombre</th>
        <th>Correo</th>
        <th>Rol</th>
        <th>Estado</th>
        <th>Creado</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td><?php echo htmlspecialchars($u['username']); ?></td>
          <td><?php echo htmlspecialchars($u['name']); ?></td>
          <td><?php echo htmlspecialchars($u['email']); ?></td>
          <td><span class="badge bg-info text-dark text-uppercase"><?php echo htmlspecialchars($u['role']); ?></span></td>
          <td><?php echo $u['active'] ? 'Activo' : 'Inactivo'; ?></td>
          <td><?php echo htmlspecialchars($u['created_at']); ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
