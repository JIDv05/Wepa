<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('admin');

$msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)($_POST['id'] ?? 0);
  $name = trim($_POST['name'] ?? '');
  $description = trim($_POST['description'] ?? '');
  if ($id === 0) {
    $pdo->prepare("INSERT INTO departments (name,description) VALUES (?,?)")->execute([$name, $description]);
    $msg = "Departamento creado.";
  } else {
    $pdo->prepare("UPDATE departments SET name=?, description=? WHERE id=?")->execute([$name, $description, $id]);
    $msg = "Departamento actualizado.";
  }
}

if (isset($_GET['del'])) {
  $pdo->prepare("DELETE FROM departments WHERE id=?")->execute([(int)$_GET['del']]);
  $msg = "Departamento eliminado.";
}

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="h5 mb-0">Departamentos</h2>
    <p class="text-secondary small mb-0">Organiza la estructura de la empresa.</p>
  </div>
  <button class="btn-soft-primary" data-bs-toggle="modal" data-bs-target="#modalDepto">
    <i class="bi bi-plus-circle me-1"></i> Nuevo
  </button>
</div>
<?php if ($msg): ?><div class="alert alert-success py-2 small flash-message"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
<div class="app-card p-3">
  <div class="table-responsive">
    <table class="table table-dark app-table table-striped small mb-0 align-middle">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Descripción</th>
          <th class="text-end">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($departments as $d): ?>
          <tr>
            <td><?php echo htmlspecialchars($d['name']); ?></td>
            <td><?php echo htmlspecialchars($d['description']); ?></td>
            <td class="text-end">
              <button 
                class="btn btn-sm btn-outline-light me-1"
                data-bs-toggle="modal"
                data-bs-target="#modalDepto"
                data-id="<?php echo $d['id']; ?>"
                data-name="<?php echo htmlspecialchars($d['name']); ?>"
                data-desc="<?php echo htmlspecialchars($d['description']); ?>"
              ><i class="bi bi-pencil"></i></button>
              <a href="?del=<?php echo $d['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar departamento?');"><i class="bi bi-trash"></i></a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="modalDepto" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content bg-dark text-light border-secondary">
      <form method="post">
        <div class="modal-header border-secondary">
          <h5 class="modal-title">Departamento</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="dept-id">
          <div class="mb-3">
            <label class="form-label small">Nombre</label>
            <input type="text" name="name" id="dept-name" class="form-control" required>
          </div>
          <div>
            <label class="form-label small">Descripción</label>
            <textarea name="description" id="dept-desc" class="form-control" rows="3"></textarea>
          </div>
        </div>
        <div class="modal-footer border-secondary">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn-soft-primary">Guardar</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script>
  const modalDept = document.getElementById('modalDepto');
  modalDept.addEventListener('show.bs.modal', e => {
    const b = e.relatedTarget;
    const id = b.getAttribute('data-id');
    const name = b.getAttribute('data-name') || '';
    const desc = b.getAttribute('data-desc') || '';
    document.getElementById('dept-id').value = id || 0;
    document.getElementById('dept-name').value = name;
    document.getElementById('dept-desc').value = desc;
  });
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
