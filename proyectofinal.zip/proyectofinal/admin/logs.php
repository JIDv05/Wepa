<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('admin');

$logs = $pdo->query("SELECT l.*, u.username 
                     FROM logs l
                     LEFT JOIN users u ON u.id=l.user_id
                     ORDER BY l.created_at DESC
                     LIMIT 100")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="app-card p-3">
  <h2 class="h6 mb-3">Auditoría / Logs del sistema</h2>
  <div class="table-responsive">
    <table class="table table-dark app-table table-striped small mb-0 align-middle">
      <thead>
        <tr>
          <th>Fecha</th>
          <th>Usuario</th>
          <th>Acción</th>
          <th>Detalles</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($logs as $l): ?>
          <tr>
            <td><?php echo htmlspecialchars($l['created_at']); ?></td>
            <td><?php echo htmlspecialchars($l['username'] ?? 'sistema'); ?></td>
            <td><?php echo htmlspecialchars($l['action']); ?></td>
            <td><?php echo nl2br(htmlspecialchars($l['details'] ?? '')); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
