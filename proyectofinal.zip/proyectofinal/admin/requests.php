<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('admin');

if (isset($_GET['approve']) || isset($_GET['reject'])) {
  $id = (int)($_GET['approve'] ?? $_GET['reject']);
  $status = isset($_GET['approve']) ? 'aprobado' : 'rechazado';
  $user = current_user();
  $pdo->prepare("UPDATE requests SET status=?, approver_id=?, updated_at=NOW() WHERE id=?")
      ->execute([$status, $user['id'], $id]);
}

$reqs = $pdo->query("SELECT r.*, u.name AS employee
                     FROM requests r
                     JOIN users u ON u.id=r.user_id
                     ORDER BY r.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="h5 mb-0">Solicitudes</h2>
    <p class="text-secondary small mb-0">Vacaciones y permisos.</p>
  </div>
</div>
<div class="app-card p-3">
  <div class="table-responsive">
    <table class="table table-dark app-table table-striped small mb-0 align-middle">
      <thead>
        <tr>
          <th>Empleado</th>
          <th>Tipo</th>
          <th>Desde</th>
          <th>Hasta</th>
          <th>Estado</th>
          <th class="text-end">Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($reqs as $r): ?>
          <tr>
            <td><?php echo htmlspecialchars($r['employee']); ?></td>
            <td><?php echo htmlspecialchars($r['type']); ?></td>
            <td><?php echo htmlspecialchars($r['start_date']); ?></td>
            <td><?php echo htmlspecialchars($r['end_date']); ?></td>
            <td>
              <span class="badge 
                <?php 
                  echo $r['status']==='pendiente' ? 'bg-warning text-dark' : 
                       ($r['status']==='aprobado' ? 'bg-success' : 'bg-danger');
                ?>">
                <?php echo htmlspecialchars($r['status']); ?>
              </span>
            </td>
            <td class="text-end">
              <?php if ($r['status']==='pendiente'): ?>
                <a href="?approve=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-success me-1">Aprobar</a>
                <a href="?reject=<?php echo $r['id']; ?>" class="btn btn-sm btn-outline-danger">Rechazar</a>
              <?php else: ?>
                <span class="text-secondary small">Gestionado</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
