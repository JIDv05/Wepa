<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('admin');

$msg = null;

// Crear/editar
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = (int)($_POST['id'] ?? 0);
  $name = trim($_POST['name'] ?? '');
  $username = trim($_POST['username'] ?? '');
  $email = trim($_POST['email'] ?? '');
  $role = $_POST['role'] ?? 'empleado';
  $department_id = $_POST['department_id'] ?: null;
  $position_id = $_POST['position_id'] ?: null;
  $status = $_POST['status'] ?? 'activo';
  $password = $_POST['password'] ?? '';

  if ($id === 0) {
    // nuevo usuario + empleado
    $hash = password_hash($password ?: '123456', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username,password_hash,name,email,role,active) VALUES (?,?,?,?,?,1)");
    $stmt->execute([$username, $hash, $name, $email, $role]);
    $uid = $pdo->lastInsertId();
    $stmt2 = $pdo->prepare("INSERT INTO employees (user_id,department_id,position_id,hire_date,status) VALUES (?,?,?,CURDATE(),?)");
    $stmt2->execute([$uid, $department_id, $position_id, $status]);
    $msg = "Empleado creado correctamente.";
  } else {
    // actualizar
    $fieldsUser = [
      'username' => $username,
      'name' => $name,
      'email' => $email,
      'role' => $role,
      'id' => $id
    ];
    $sql = "UPDATE users SET username=:username,name=:name,email=:email,role=:role";
    if ($password !== '') {
      $sql .= ", password_hash=:password_hash";
      $fieldsUser['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
    }
    $sql .= " WHERE id=:id";
    $pdo->prepare($sql)->execute($fieldsUser);
    $pdo->prepare("UPDATE employees SET department_id=?, position_id=?, status=? WHERE user_id=?")
        ->execute([$department_id, $position_id, $status, $id]);
    $msg = "Empleado actualizado.";
  }
}

// Eliminar
if (isset($_GET['delete'])) {
  $uid = (int)$_GET['delete'];
  $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$uid]);
  $msg = "Empleado eliminado.";
}

$departments = $pdo->query("SELECT * FROM departments ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$positions = $pdo->query("SELECT p.*, d.name AS department_name
                          FROM positions p
                          LEFT JOIN departments d ON d.id=p.department_id
                          ORDER BY d.name, p.name")->fetchAll(PDO::FETCH_ASSOC);

$employees = $pdo->query("SELECT u.id,u.username,u.name,u.email,u.role,u.active,
                                 e.status,
                                 d.name AS dept,
                                 p.name AS position
                          FROM users u
                          LEFT JOIN employees e ON e.user_id=u.id
                          LEFT JOIN departments d ON d.id=e.department_id
                          LEFT JOIN positions p ON p.id=e.position_id
                          WHERE u.role IN ('admin','gerente','empleado')
                          ORDER BY u.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h2 class="h5 mb-0">Gestión de Empleados</h2>
    <p class="text-secondary small mb-0">Crea, edita y administra al personal.</p>
  </div>
  <button class="btn-soft-primary" data-bs-toggle="modal" data-bs-target="#modalEmpleado">
    <i class="bi bi-plus-circle me-1"></i> Nuevo empleado
  </button>
</div>

<?php if ($msg): ?>
  <div class="alert alert-success py-2 small flash-message"><?php echo htmlspecialchars($msg); ?></div>
<?php endif; ?>

<div class="app-card p-3">
  <div class="table-responsive">
    <table class="table table-dark table-striped align-middle app-table small mb-0">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Usuario</th>
          <th>Rol</th>
          <th>Departamento</th>
          <th>Puesto</th>
          <th>Estado</th>
          <th class="text-end">Acciones</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($employees as $e): ?>
        <tr>
          <td><?php echo htmlspecialchars($e['name']); ?></td>
          <td><?php echo htmlspecialchars($e['username']); ?></td>
          <td><span class="badge bg-info text-dark text-uppercase"><?php echo htmlspecialchars($e['role']); ?></span></td>
          <td><?php echo htmlspecialchars($e['dept'] ?? '-'); ?></td>
          <td><?php echo htmlspecialchars($e['position'] ?? '-'); ?></td>
          <td>
            <span class="status-pill badge <?php echo $e['status']==='activo' ? 'bg-success' : 'bg-secondary'; ?>">
              <?php echo $e['status'] ?? 'N/A'; ?>
            </span>
          </td>
          <td class="text-end">
            <button 
              class="btn btn-sm btn-outline-light me-1"
              data-bs-toggle="modal"
              data-bs-target="#modalEmpleado"
              data-id="<?php echo $e['id']; ?>"
              data-name="<?php echo htmlspecialchars($e['name']); ?>"
              data-username="<?php echo htmlspecialchars($e['username']); ?>"
              data-email="<?php echo htmlspecialchars($e['email']); ?>"
              data-role="<?php echo htmlspecialchars($e['role']); ?>"
              data-status="<?php echo htmlspecialchars($e['status'] ?? 'activo'); ?>"
            >
              <i class="bi bi-pencil"></i>
            </button>
            <a href="?delete=<?php echo $e['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('¿Eliminar empleado?');">
              <i class="bi bi-trash"></i>
            </a>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalEmpleado" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content bg-dark text-light border-secondary">
      <form method="post">
        <div class="modal-header border-secondary">
          <h5 class="modal-title">Empleado</h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id" id="emp-id">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label small">Nombre</label>
              <input type="text" name="name" id="emp-name" class="form-control" required>
            </div>
            <div class="col-md-3">
              <label class="form-label small">Usuario</label>
              <input type="text" name="username" id="emp-username" class="form-control" required>
            </div>
            <div class="col-md-3">
              <label class="form-label small">Correo</label>
              <input type="email" name="email" id="emp-email" class="form-control">
            </div>
            <div class="col-md-4">
              <label class="form-label small">Rol</label>
              <select name="role" id="emp-role" class="form-select">
                <option value="admin">Administrador</option>
                <option value="gerente">Gerente</option>
                <option value="empleado">Empleado</option>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label small">Departamento</label>
              <select name="department_id" class="form-select">
                <option value="">-- Sin asignar --</option>
                <?php foreach ($departments as $d): ?>
                  <option value="<?php echo $d['id']; ?>"><?php echo htmlspecialchars($d['name']); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label small">Puesto</label>
              <select name="position_id" class="form-select">
                <option value="">-- Sin asignar --</option>
                <?php foreach ($positions as $p): ?>
                  <option value="<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['department_name'] . ' - ' . $p['name']); ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-4">
              <label class="form-label small">Estado</label>
              <select name="status" id="emp-status" class="form-select">
                <option value="activo">Activo</option>
                <option value="inactivo">Inactivo</option>
              </select>
            </div>
            <div class="col-md-8">
              <label class="form-label small">Contraseña (solo si deseas cambiarla)</label>
              <input type="password" name="password" class="form-control" placeholder="Dejar vacío para no cambiar">
            </div>
          </div>
        </div>
        <div class="modal-footer border-secondary">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn-soft-primary">Guardar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  const modalEmpleado = document.getElementById('modalEmpleado');
  modalEmpleado.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    const id = button.getAttribute('data-id');
    const name = button.getAttribute('data-name') || '';
    const username = button.getAttribute('data-username') || '';
    const email = button.getAttribute('data-email') || '';
    const role = button.getAttribute('data-role') || 'empleado';
    const status = button.getAttribute('data-status') || 'activo';

    document.getElementById('emp-id').value = id || 0;
    document.getElementById('emp-name').value = name;
    document.getElementById('emp-username').value = username;
    document.getElementById('emp-email').value = email;
    document.getElementById('emp-role').value = role;
    document.getElementById('emp-status').value = status;
  });
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
