<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('empleado');
$user = current_user();

$msg = null;
if (isset($_POST['action'])) {
  $action = $_POST['action'];
  $stmt = $pdo->prepare("SELECT * FROM attendance WHERE user_id=? AND date=CURDATE()");
  $stmt->execute([$user['id']]);
  $today = $stmt->fetch(PDO::FETCH_ASSOC);
  if ($action === 'in') {
    if ($today && $today['check_in']) {
      $msg = "Ya registraste tu entrada.";
    } else {
      $pdo->prepare("INSERT INTO attendance (user_id,date,check_in,status)
                     VALUES (?,CURDATE(),CURTIME(),'presente')
                     ON DUPLICATE KEY UPDATE check_in=IFNULL(check_in,CURTIME()), status='presente'")
          ->execute([$user['id']]);
      $msg = "Entrada registrada.";
    }
  } elseif ($action === 'out') {
    if ($today && $today['check_out']) {
      $msg = "Ya registraste tu salida.";
    } else {
      $pdo->prepare("UPDATE attendance SET check_out=CURTIME() WHERE user_id=? AND date=CURDATE()")
          ->execute([$user['id']]);
      $msg = "Salida registrada.";
    }
  }
}

$hist = $pdo->prepare("SELECT * FROM attendance WHERE user_id=? ORDER BY date DESC LIMIT 30");
$hist->execute([$user['id']]);
$histRows = $hist->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="app-card p-3 h-100">
      <h2 class="h6 mb-3">Asistencia de hoy</h2>
      <?php if ($msg): ?><div class="alert alert-info py-2 small flash-message"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
      <form method="post" class="d-flex flex-column gap-2">
        <button name="action" value="in" class="btn-soft-primary" type="submit">
          <i class="bi bi-box-arrow-in-right me-1"></i> Marcar entrada
        </button>
        <button name="action" value="out" class="btn btn-outline-light btn-sm" type="submit">
          <i class="bi bi-box-arrow-left me-1"></i> Marcar salida
        </button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="app-card p-3 h-100">
      <h2 class="h6 mb-3">Historial reciente</h2>
      <div class="table-responsive">
        <table class="table table-dark app-table table-striped small mb-0 align-middle">
          <thead>
            <tr>
              <th>Fecha</th>
              <th>Entrada</th>
              <th>Salida</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($histRows as $h): ?>
              <tr>
                <td><?php echo htmlspecialchars($h['date']); ?></td>
                <td><?php echo htmlspecialchars($h['check_in']); ?></td>
                <td><?php echo htmlspecialchars($h['check_out']); ?></td>
                <td><?php echo htmlspecialchars($h['status']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
