<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('empleado');

$user = current_user();
$uid = $user['id'];

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';

$stmt = $pdo->prepare("
    SELECT period_start, period_end, base_salary, overtime, deductions, net_pay, created_at
    FROM payroll
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$uid]);
$payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="app-card p-4">
    <h2 class="h5 mb-3">Mi Nómina</h2>

    <?php if(empty($payments)): ?>
        <p class="text-muted small">Aún no tienes pagos registrados.</p>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table table-bordered small">
            <thead class="table-light">
                <tr>
                    <th>Periodo</th>
                    <th>Salario</th>
                    <th>Extra</th>
                    <th>Deducciones</th>
                    <th>Neto</th>
                    <th>Registro</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($payments as $p): ?>
                <tr>
                    <td><?= $p['period_start']; ?> a <?= $p['period_end']; ?></td>
                    <td>L. <?= number_format($p['base_salary'],2); ?></td>
                    <td>L. <?= number_format($p['overtime'],2); ?></td>
                    <td>L. <?= number_format($p['deductions'],2); ?></td>
                    <td><strong>L. <?= number_format($p['net_pay'],2); ?></strong></td>
                    <td><?= $p['created_at']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
