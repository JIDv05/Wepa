<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('empleado');
$user = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $type = $_POST['type'] ?? 'vacaciones';
  $start = $_POST['start_date'] ?? null;
  $end = $_POST['end_date'] ?? null;
  $reason = $_POST['reason'] ?? null;
  $stmt = $pdo->prepare("INSERT INTO requests (user_id,type,start_date,end_date,reason) VALUES (?,?,?,?,?)");
  $stmt->execute([$user['id'], $type, $start, $end, $reason]);
}

$stmt = $pdo->prepare("SELECT * FROM requests WHERE user_id=? ORDER BY created_at DESC");
$stmt->execute([$user['id']]);
$reqs = $stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="app-card p-3 h-100">
      <h2 class="h6 mb-3">Nueva solicitud</h2>
      <form method="post" class="d-flex flex-column gap-2 small">
        <div>
          <label class="form-label small">Tipo</label>
          <select name="type" class="form-select">
            <option value="vacaciones">Vacaciones</option>
            <option value="permiso">Permiso</option>
          </select>
        </div>
        <div>
          <label class="form-label small">Desde</label>
          <input type="date" name="start_date" class="form-control" required>
        </div>
        <div>
          <label class="form-label small">Hasta</label>
          <input type="date" name="end_date" class="form-control" required>
        </div>
        <div>
          <label class="form-label small">Motivo</label>
          <textarea name="reason" rows="3" class="form-control"></textarea>
        </div>
        <button class="btn-soft-primary mt-2">Enviar solicitud</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="app-card p-3 h-100">
      <h2 class="h6 mb-3">Mis solicitudes</h2>
      <div class="table-responsive">
        <table class="table table-dark app-table table-striped small mb-0 align-middle">
          <thead>
            <tr>
              <th>Tipo</th>
              <th>Desde</th>
              <th>Hasta</th>
              <th>Estado</th>
              <th>Creado</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($reqs as $r): ?>
              <tr>
                <td><?php echo htmlspecialchars($r['type']); ?></td>
                <td><?php echo htmlspecialchars($r['start_date']); ?></td>
                <td><?php echo htmlspecialchars($r['end_date']); ?></td>
                <td>
                  <span class="badge 
                    <?php 
                      echo $r['status']==='pendiente' ? 'bg-warning text-dark' : 
                           ($r['status']==='aprobado' ? 'bg-success' : 'bg-danger');
                    ?>">
                    <?php echo htmlspecialchars($r['status']); ?>
                  </span>
                </td>
                <td><?php echo htmlspecialchars($r['created_at']); ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
