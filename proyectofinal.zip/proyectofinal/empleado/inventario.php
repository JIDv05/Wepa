<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

$user = current_user();
$role = $user['role'] ?? null;

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';

/
if ($role === "gerente" && isset($_POST["add"])) {
    $stmt = $pdo->prepare("
        INSERT INTO inventory (name, category, quantity, price) 
        VALUES (?, ?, ?, ?)
    ");

    $stmt->execute([
        $_POST["name"],
        $_POST["category"],
        $_POST["quantity"],
        $_POST["price"]
    ]);

    $msg = "Producto agregado correctamente.";
}


if ($role === "gerente" && isset($_POST["edit"])) {

    $stmt = $pdo->prepare("
        UPDATE inventory SET name=?, category=?, quantity=?, price=? WHERE id=?
    ");

    $stmt->execute([
        $_POST["name"],
        $_POST["category"],
        $_POST["quantity"],
        $_POST["price"],
        $_POST["id"]
    ]);

    $msg = "Producto actualizado.";
}


if ($role === "gerente" && isset($_GET["delete"])) {

    $stmt = $pdo->prepare("DELETE FROM inventory WHERE id=?");
    $stmt->execute([ $_GET["delete"] ]);

    $msg = "Producto eliminado.";
}


$filter  = $_GET["filter"] ?? "";
$search  = $_GET["search"] ?? "";

$sql = "SELECT * FROM inventory WHERE 1";

if ($filter !== "") {
    $sql .= " AND category = " . $pdo->quote($filter);
}

if ($search !== "") {
    $search = "%$search%";
    $sql .= " AND name LIKE " . $pdo->quote($search);
}

$sql .= " ORDER BY created_at DESC";

$items = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="app-card p-4">

    <h2 class="h5 mb-3">Inventario</h2>

    <?php if (!empty($msg)): ?>
        <div class="alert alert-success"><?= $msg ?></div>
    <?php endif; ?>

    
    <form class="row g-2 mb-4">

        <div class="col-md-4">
            <input type="text" class="form-control" name="search" 
                   placeholder="Buscar producto..." 
                   value="<?= htmlspecialchars($search) ?>">
        </div>

        <div class="col-md-3">
            <select name="filter" class="form-select">
                <option value="">Todas las categorías</option>
                <option value="Electrónica" <?= $filter=='Electrónica'?'selected':'' ?>>Electrónica</option>
                <option value="Ropa" <?= $filter=='Ropa'?'selected':'' ?>>Ropa</option>
                <option value="Comida" <?= $filter=='Comida'?'selected':'' ?>>Comida</option>
                <option value="Otro" <?= $filter=='Otro'?'selected':'' ?>>Otro</option>
            </select>
        </div>

        <div class="col-md-2">
            <button class="btn btn-secondary w-100">Filtrar</button>
        </div>

    </form>


    <?php if ($role === "gerente"): ?>

    <button class="btn btn-primary mb-3" data-bs-toggle="collapse" data-bs-target="#addForm">
        Agregar Producto
    </button>

    <div id="addForm" class="collapse mb-4">
        <form method="POST" class="row g-3">

            <input type="hidden" name="add" value="1">

            <div class="col-md-4">
                <label>Nombre</label>
                <input class="form-control" name="name" required>
            </div>

            <div class="col-md-3">
                <label>Categoría</label>
                <input class="form-control" name="category">
            </div>

            <div class="col-md-2">
                <label>Cantidad</label>
                <input type="number" class="form-control" name="quantity" value="0">
            </div>

            <div class="col-md-2">
                <label>Precio</label>
                <input type="number" step="0.01" class="form-control" name="price" value="0">
            </div>

            <div class="col-md-12">
                <button class="btn btn-success">Guardar</button>
            </div>

        </form>
    </div>

    <?php endif; ?>

 
    <div class="table-responsive">
        <table class="table table-bordered table-hover small">
            <thead class="table-light">
                <tr>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Cantidad</th>
                    <th>Precio</th>
                    <th>Registrado</th>
                    <?php if ($role === "gerente"): ?>
                        <th>Acciones</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $i): ?>
                <tr>
                    <td><?= $i["name"] ?></td>
                    <td><?= $i["category"] ?></td>
                    <td><?= $i["quantity"] ?></td>
                    <td>L. <?= number_format($i["price"],2) ?></td>
                    <td><?= $i["created_at"] ?></td>

                    <?php if ($role === "gerente"): ?>
                    <td>
                        <button class="btn btn-sm btn-warning"
                                data-bs-toggle="modal"
                                data-bs-target="#edit<?= $i["id"] ?>">
                            Editar
                        </button>

                        <a href="?delete=<?= $i["id"] ?>" 
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('¿Eliminar producto?')">
                           Eliminar
                        </a>
                    </td>
                    <?php endif; ?>
                </tr>

                <?php if ($role === "gerente"): ?>
                <div class="modal fade" id="edit<?= $i["id"] ?>">
                    <div class="modal-dialog">
                        <form method="POST" class="modal-content">

                            <div class="modal-header">
                                <h5 class="modal-title">Editar Producto</h5>
                                <button class="btn-close" data-bs-dismiss="modal"></button>
                            </div>

                            <div class="modal-body row g-3">

                                <input type="hidden" name="edit" value="1">
                                <input type="hidden" name="id" value="<?= $i["id"] ?>">

                                <div class="col-md-6">
                                    <label>Nombre</label>
                                    <input class="form-control" name="name" value="<?= $i["name"] ?>" required>
                                </div>

                                <div class="col-md-6">
                                    <label>Categoría</label>
                                    <input class="form-control" name="category" value="<?= $i["category"] ?>">
                                </div>

                                <div class="col-md-6">
                                    <label>Cantidad</label>
                                    <input type="number" class="form-control" name="quantity" value="<?= $i["quantity"] ?>">
                                </div>

                                <div class="col-md-6">
                                    <label>Precio</label>
                                    <input type="number" step="0.01" class="form-control" name="price" value="<?= $i["price"] ?>">
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button class="btn btn-success">Actualizar</button>
                                <button class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                            </div>

                        </form>
                    </div>
                </div>
                <?php endif; ?>

                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
