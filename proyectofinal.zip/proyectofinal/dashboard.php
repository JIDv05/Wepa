<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_login();
$user = current_user();


$totalEmpleados = (int)$pdo->query("SELECT COUNT(*) FROM employees")->fetchColumn();
$empleadosActivos = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE status='activo'")->fetchColumn();
$solPendientes = (int)$pdo->query("SELECT COUNT(*) FROM requests WHERE status='pendiente'")->fetchColumn();
$asistenciaHoy = (int)$pdo->query("SELECT COUNT(*) FROM attendance WHERE date = CURDATE()")->fetchColumn();

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/sidebar.php';
?>

<div class="row g-4 mb-4">
  <div class="col-12 col-md-6 col-xl-3">
    <div class="app-card p-3 h-100">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div>
          <div class="badge-soft mb-1">Empleados</div>
          <div class="stat-number"><?php echo $totalEmpleados; ?></div>
          <div class="stat-label">Registrados en el sistema</div>
        </div>
        <i class="bi bi-people fs-3 text-primary"></i>
      </div>
      <div class="d-flex justify-content-between align-items-center small text-secondary">
        <span>Activos: <span class="text-light"><?php echo $empleadosActivos; ?></span></span>
        <a href="/proyectofinal/admin/employees.php" class="link-light text-decoration-none small">Ver más</a>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="app-card p-3 h-100">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div>
          <div class="badge-soft mb-1">Solicitudes</div>
          <div class="stat-number"><?php echo $solPendientes; ?></div>
          <div class="stat-label">Pendientes de revisión</div>
        </div>
        <i class="bi bi-envelope-open fs-3 text-info"></i>
      </div>
      <div class="small text-secondary">
        Gestiona vacaciones y permisos.
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="app-card p-3 h-100">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div>
          <div class="badge-soft mb-1">Asistencia</div>
          <div class="stat-number"><?php echo $asistenciaHoy; ?></div>
          <div class="stat-label">Registros del día</div>
        </div>
        <i class="bi bi-calendar-check fs-3 text-success"></i>
      </div>
      <div class="small text-secondary">
   
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-3">
    <div class="app-card p-3 h-100">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <div>
          <div class="badge-soft mb-1">Bienvenido</div>
          <div class="stat-number" style="font-size:1.2rem;">
            <?php echo htmlspecialchars($user['name']); ?>
          </div>
          <div class="stat-label text-uppercase"> <?php echo htmlspecialchars($user['role']); ?></div>
        </div>
        <i class="bi bi-person-circle fs-3 text-warning"></i>
      </div>
      <div class="small text-secondary">
        
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
