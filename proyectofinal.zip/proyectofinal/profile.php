<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_login();
$user = current_user();
$msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $pass = $_POST['password'] ?? '';
    $fields = ['name' => $name, 'email' => $email];
    $sql = "UPDATE users SET name=:name, email=:email";
    if ($pass !== '') {
        $sql .= ", password_hash=:password_hash";
        $fields['password_hash'] = password_hash($pass, PASSWORD_DEFAULT);
    }
    $sql .= " WHERE id=:id";
    $fields['id'] = $user['id'];
    $stmt = $pdo->prepare($sql);
    $stmt->execute($fields);
    $_SESSION['user']['name'] = $name;
    $_SESSION['user']['email'] = $email;
    $msg = "Perfil actualizado correctamente.";
}

$stmt = $pdo->prepare("SELECT * FROM users WHERE id=?");
$stmt->execute([$user['id']]);
$dbUser = $stmt->fetch(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/sidebar.php';
?>
<div class="row justify-content-center">
  <div class="col-12 col-lg-6">
    <div class="app-card p-4">
      <h2 class="h5 mb-3">Mi Perfil</h2>
      <?php if ($msg): ?>
        <div class="alert alert-success py-2 small"><?php echo htmlspecialchars($msg); ?></div>
      <?php endif; ?>
      <form method="post" class="d-flex flex-column gap-3">
        <div>
          <label class="form-label small text-secondary">Nombre completo</label>
          <input type="text" name="name" class="form-control" required value="<?php echo htmlspecialchars($dbUser['name']); ?>">
        </div>
        <div>
          <label class="form-label small text-secondary">Correo</label>
          <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($dbUser['email'] ?? ''); ?>">
        </div>
        <div>
          <label class="form-label small text-secondary">Nueva contraseña</label>
          <input type="password" name="password" class="form-control" placeholder="Dejar en blanco para no cambiar">
        </div>
        <button class="btn-soft-primary align-self-start">Guardar cambios</button>
      </form>
    </div>
  </div>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
