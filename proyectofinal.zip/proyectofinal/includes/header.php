<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$user = $_SESSION['user'] ?? null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Proyecto Final</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
   
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    <link rel="stylesheet" href="/proyectofinal/assets/css/style.css">
</head>
<body>
<div class="app-wrapper">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm app-navbar">
      <div class="container-fluid">
        <a class="navbar-brand fw-bold d-flex align-items-center gap-2" href="/proyectofinal/dashboard.php">
          <i class="bi bi-grid-1x2-fill"></i> JIREH MINIMARKET
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarMain">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-lg-center">
            <?php if ($user): ?>
              <li class="nav-item me-3 text-light small">
                <span class="text-secondary"></span>
                <span class="badge bg-primary text-uppercase ms-1"><?php echo htmlspecialchars($user['role']); ?></span>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle d-flex align-items-center gap-2" href="#" role="button" data-bs-toggle="dropdown">
                  <i class="bi bi-person-circle fs-5"></i>
                  <span><?php echo htmlspecialchars($user['name'] ?? $user['username']); ?></span>
                </a>
                <ul class="dropdown-menu dropdown-menu-end shadow">
                  <li><a class="dropdown-item" href="/proyectofinal/profile.php"><i class="bi bi-person me-2"></i>Mi perfil</a></li>
                  <li><a class="dropdown-item" href="/proyectofinal/notifications.php"><i class="bi bi-bell me-2"></i>Notificaciones</a></li>
                  <li><hr class="dropdown-divider"></li>
                  <li><a class="dropdown-item text-danger" href="/proyectofinal/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Salir</a></li>
                </ul>
              </li>
            <?php else: ?>
              <li class="nav-item">
                <a class="btn btn-outline-light btn-sm" href="/proyectofinal/login.php">Iniciar sesión</a>
              </li>
            <?php endif; ?>
          </ul>
        </div>
      </div>
    </nav>
    <div class="app-body d-flex">
