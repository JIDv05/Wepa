<?php
require_once __DIR__ . '/auth.php';
$user = current_user();
$role = $user['role'] ?? null;
?>
<aside class="app-sidebar bg-body-tertiary border-end">
  <div class="p-3">
    <div class="fw-semibold text-secondary text-uppercase small mb-2">Menú</div>

    <ul class="nav nav-pills flex-column gap-1">

    
      <li class="nav-item">
        <a class="nav-link app-nav-link" href="/proyectofinal/dashboard.php">
          <i class="bi bi-speedometer2 me-2"></i>Dashboard
        </a>
      </li>


      <?php if ($role === 'admin'): ?>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/admin/employees.php">
            <i class="bi bi-people me-2"></i>Gestión de Empleados
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/admin/departments.php">
            <i class="bi bi-diagram-3 me-2"></i>Departamentos / Puestos
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/admin/users.php">
            <i class="bi bi-shield-lock me-2"></i>Usuarios y Roles
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/admin/requests.php">
            <i class="bi bi-envelope-open me-2"></i>Solicitudes
          </a>
        </li>

        

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/admin/settings.php">
            <i class="bi bi-gear me-2"></i>Configuración
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/admin/logs.php">
            <i class="bi bi-activity me-2"></i>Auditoría / Logs
          </a>
        </li>


      <?php elseif ($role === 'gerente'): ?>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/gerente/team.php">
            <i class="bi bi-people me-2"></i>Mi Equipo
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/gerente/requests.php">
            <i class="bi bi-check2-square me-2"></i>Solicitudes
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/gerente/attendance.php">
            <i class="bi bi-calendar-check me-2"></i>Asistencia
          </a>
        </li>

  

        

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/gerente/tasks.php">
            <i class="bi bi-list-check me-2"></i>Mi Agenda / Tareas
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/gerente/payroll.php">
            <i class="bi bi-receipt me-2"></i>Mi Nómina
          </a>
        </li>

   
        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/gerente/inventario.php">
            <i class="bi bi-box-seam me-2"></i>Inventario
          </a>
        </li>


      <?php elseif ($role === 'empleado'): ?>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/empleado/requests.php">
            <i class="bi bi-envelope-plus me-2"></i>Solicitudes
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/empleado/attendance.php">
            <i class="bi bi-calendar-check me-2"></i>Asistencia
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/empleado/payroll.php">
            <i class="bi bi-receipt me-2"></i>Mi Nómina
          </a>
        </li>

        
        <li class="nav-item">
          <a class="nav-link app-nav-link" href="/proyectofinal/empleado/inventario.php">
            <i class="bi bi-box-seam me-2"></i>Inventario
          </a>
        </li>

      <?php endif; ?>



      <li class="nav-item mt-2">
        <a class="nav-link app-nav-link" href="/proyectofinal/profile.php">
          <i class="bi bi-person me-2"></i>Perfil
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link app-nav-link" href="/proyectofinal/notifications.php">
          <i class="bi bi-bell me-2"></i>Notificaciones
        </a>
      </li>

    </ul>
  </div>
</aside>

<main class="app-main flex-grow-1">
  <div class="container-fluid py-4 app-main-inner">
