<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user']);
}

function current_user() {
    return $_SESSION['user'] ?? null;
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: /proyectofinal/login.php');
        exit;
    }
}

function require_role($roles) {
    require_login();
    $user = current_user();
    $roles = (array)$roles;
    if (!in_array($user['role'], $roles)) {
        header('HTTP/1.1 403 Forbidden');
        echo "<h2>Acceso denegado</h2>";
        exit;
    }
}
