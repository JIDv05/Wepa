<?php
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';


$stmt = $pdo->query("SELECT COUNT(*) AS total FROM users");
$total = (int)$stmt->fetch(PDO::FETCH_ASSOC)['total'];
if ($total === 0) {
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    $pdo->prepare("INSERT INTO users (username,password_hash,name,email,role) VALUES (?,?,?,?,?)")
        ->execute(['admin', $hash, 'Administrador General', 'admin@example.com', 'admin']);
}

$error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND active = 1 LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($user && password_verify($password, $user['password_hash'])) {
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role' => $user['role'],
        ];
        $pdo->prepare("INSERT INTO logs (user_id, action, details) VALUES (?,?,?)")
            ->execute([$user['id'], 'login', 'Inicio de sesión']);
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Credenciales incorrectas.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Login - Proyecto Final</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="/proyectofinal/assets/css/style.css">
</head>
<body>
<div class="glow-orbit"></div>
<section class="login-hero container">
  <div class="login-card app-card p-4 p-md-5 position-relative">
    <div class="mb-4 text-center">
 
      <h1 class="h4 fw-semibold mb-1 text-gradient">JIREH MINIMARKET</h1>
      <p class="text-secondary small mb-0">Inicia sesión para continuar</p>
    </div>
    <?php if ($error): ?>
      <div class="alert alert-danger py-2 small"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    <form method="post" class="d-flex flex-column gap-3">
      <div>
        <label class="form-label small text-secondary">Usuario</label>
        <input type="text" name="username" class="form-control" required autofocus>
      </div>
      <div>
        <label class="form-label small text-secondary">Contraseña</label>
        <input type="password" name="password" class="form-control" required>
   
      </div>
      <button class="btn-soft-primary w-100 mt-2">Entrar al sistema</button>
    </form>
  </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
