<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('gerente');
$user = current_user();


$employees = $pdo->query("SELECT u.name,u.email,d.name AS dept,p.name AS position
                          FROM employees e
                          JOIN users u ON u.id=e.user_id
                          LEFT JOIN departments d ON d.id=e.department_id
                          LEFT JOIN positions p ON p.id=e.position_id")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="app-card p-3">
  <h2 class="h5 mb-3">Mi Equipo</h2>
  <p class="text-secondary small">Como demo, se listan todos los empleados.</p>
  <div class="table-responsive">
    <table class="table table-dark app-table table-striped small mb-0 align-middle">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Correo</th>
          <th>Departamento</th>
          <th>Puesto</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($employees as $e): ?>
          <tr>
            <td><?php echo htmlspecialchars($e['name']); ?></td>
            <td><?php echo htmlspecialchars($e['email']); ?></td>
            <td><?php echo htmlspecialchars($e['dept']); ?></td>
            <td><?php echo htmlspecialchars($e['position']); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
