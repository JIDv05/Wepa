<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';

require_role('gerente');
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';


$success = "";
$error = "";


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['titulo'])) {

    if (trim($_POST['titulo']) === "") {
        $error = "❌ La tarea no puede estar vacía.";
    } else {
        $stmt = $pdo->prepare("INSERT INTO tasks (usuario_id, titulo) VALUES (:uid, :titulo)");
        $ok = $stmt->execute([
            ':uid' => $user_id,
            ':titulo' => trim($_POST['titulo'])
        ]);

        if ($ok) $success = "✔️ Tarea agregada correctamente.";
    }
}


if (isset($_GET['done'])) {
    $stmt = $pdo->prepare("UPDATE tasks SET completado = 1 WHERE id = :id AND usuario_id = :uid");
    $stmt->execute([
        ':id' => $_GET['done'],
        ':uid' => $user_id
    ]);

    header("Location: tasks.php");
    exit;
}


$stmt = $pdo->prepare("
    SELECT * FROM tasks 
    WHERE usuario_id = :uid 
    ORDER BY completado ASC, id DESC
");

$tareas = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="app-card p-4">
    <h2 class="h5 fw-bold mb-4">📝 Mi Agenda / Mis Tareas</h2>

   
    <?php if($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="alert alert-danger"><?= $error ?></div>
    <?php endif; ?>


    <form method="POST" class="mb-4 bg-white p-3 border rounded">
        <label class="fw-bold small mb-1">Nueva tarea:</label>
        <div class="d-flex gap-2">
            <input type="text" name="titulo" class="form-control" placeholder="Ej: revisar reportes" required>
            <button class="btn btn-primary"><i class="fa fa-plus"></i> Agregar</button>
        </div>
    </form>


 
    <h6 class="fw-bold mb-3 mt-3">📋 Tareas Pendientes</h6>

    <?php if(empty($tareas)): ?>
        <p class="text-secondary small">No tienes tareas agregadas aún.</p>

    <?php else: ?>

        <ul class="list-group mb-4">

            <?php foreach($tareas as $t): ?>

                <li class="list-group-item d-flex justify-content-between align-items-center 
                    <?= $t['completado'] ? 'text-decoration-line-through text-muted' : '' ?>">

                    <span><?= htmlspecialchars($t['titulo']) ?></span>

                    <?php if(!$t['completado']): ?>
                        <a href="tasks.php?done=<?= $t['id'] ?>" class="btn btn-sm btn-success">
                            <i class="fa fa-check"></i>
                        </a>
                    <?php else: ?>
                        <span class="badge bg-success">Completada</span>
                    <?php endif; ?>

                </li>

            <?php endforeach; ?>

        </ul>

    <?php endif; ?>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
