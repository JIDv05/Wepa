<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('gerente');
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="app-card p-4">
  <h2 class="h5 mb-3">Reportes del equipo</h2>
  <p class="text-secondary small">
    Aquí podrías generar reportes de asistencia, desempeño y productividad. Para el proyecto final,
    puedes explicar que desde esta pantalla se exportarían datos a PDF o Excel.
  </p>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
