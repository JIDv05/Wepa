<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('gerente');
include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="app-card p-4">
  <h2 class="h5 mb-3">Documentos / Recursos</h2>
  <p class="text-secondary small">
    Pantalla demostrativa para el módulo de documents. Puedes describir su funcionamiento en tu presentación.
  </p>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
