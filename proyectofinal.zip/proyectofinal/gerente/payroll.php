<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('gerente');

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';


$employees = $pdo->query("
    SELECT id, username AS name
    FROM users
    WHERE role = 'empleado'
    ORDER BY username
")->fetchAll(PDO::FETCH_ASSOC);


if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $user_id      = $_POST['user_id'];
    $period_start = $_POST['period_start'];
    $period_end   = $_POST['period_end'];
    $base_salary  = $_POST['base_salary'];
    $overtime     = $_POST['overtime'];
    $deductions   = $_POST['deductions'];

    $net_pay = ($base_salary + $overtime) - $deductions;

    $stmt = $pdo->prepare("
        INSERT INTO payroll (user_id, period_start, period_end, base_salary, overtime, deductions, net_pay)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $user_id,
        $period_start,
        $period_end,
        $base_salary,
        $overtime,
        $deductions,
        $net_pay
    ]);

    $success = "Pago registrado correctamente.";
}


$sql = "
    SELECT p.*, u.username AS name
    FROM payroll p
    JOIN users u ON p.user_id = u.id
    ORDER BY p.created_at DESC
    LIMIT 20
";

$history = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="app-card p-4">

    <h2 class="h5 mb-3">Registrar Pago de Nómina</h2>

    <?php if(!empty($success)): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>

    <form method="POST" class="row g-3 mb-4">

        <div class="col-md-4">
            <label class="form-label">Empleado</label>
            <select name="user_id" class="form-select" required>
                <option value="">Seleccione...</option>
                <?php foreach($employees as $emp): ?>
                    <option value="<?= $emp['id']; ?>"><?= $emp['name']; ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label class="form-label">Periodo Inicio</label>
            <input type="date" name="period_start" class="form-control" required>
        </div>

        <div class="col-md-4">
            <label class="form-label">Periodo Fin</label>
            <input type="date" name="period_end" class="form-control" required>
        </div>

        <div class="col-md-3">
            <label class="form-label">Salario Base</label>
            <input type="number" step="0.01" name="base_salary" class="form-control" required>
        </div>

        <div class="col-md-3">
            <label class="form-label">Horas Extra</label>
            <input type="number" step="0.01" name="overtime" class="form-control" required>
        </div>

        <div class="col-md-3">
            <label class="form-label">Deducciones</label>
            <input type="number" step="0.01" name="deductions" class="form-control" required>
        </div>

        <div class="col-md-3 d-flex align-items-end justify-content-end">
            <button class="btn btn-primary w-100">Guardar Pago</button>
        </div>

    </form>

    <hr/>


    <h2 class="h6 mb-3">Historial Reciente</h2>

    <?php if(empty($history)): ?>
        <p class="text-muted small">No hay pagos registrados.</p>

    <?php else: ?>

        <div class="table-responsive">
            <table class="table table-bordered table-hover small">
                <thead class="table-light">
                    <tr>
                        <th>Empleado</th>
                        <th>Periodo</th>
                        <th>Salario</th>
                        <th>Extra</th>
                        <th>Deducciones</th>
                        <th>Neto</th>
                        <th>Fecha Registro</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($history as $h): ?>
                    <tr>
                        <td><?= $h['name']; ?></td>
                        <td><?= $h['period_start']; ?> a <?= $h['period_end']; ?></td>
                        <td>L. <?= number_format($h['base_salary'],2); ?></td>
                        <td>L. <?= number_format($h['overtime'],2); ?></td>
                        <td>L. <?= number_format($h['deductions'],2); ?></td>
                        <td><strong>L. <?= number_format($h['net_pay'],2); ?></strong></td>
                        <td><?= $h['created_at']; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
