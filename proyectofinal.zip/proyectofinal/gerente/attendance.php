<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/db.php';
require_role('gerente');

$att = $pdo->query("SELECT a.*, u.name 
                    FROM attendance a
                    JOIN users u ON u.id=a.user_id
                    WHERE a.date = CURDATE()")->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/../includes/header.php';
include __DIR__ . '/../includes/sidebar.php';
?>
<div class="app-card p-3">
  <h2 class="h5 mb-3">Asistencia de hoy</h2>
  <div class="table-responsive">
    <table class="table table-dark app-table table-striped small mb-0 align-middle">
      <thead>
        <tr>
          <th>Colaborador</th>
          <th>Entrada</th>
          <th>Salida</th>
          <th>Estado</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($att as $a): ?>
          <tr>
            <td><?php echo htmlspecialchars($a['name']); ?></td>
            <td><?php echo htmlspecialchars($a['check_in']); ?></td>
            <td><?php echo htmlspecialchars($a['check_out']); ?></td>
            <td><?php echo htmlspecialchars($a['status']); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
