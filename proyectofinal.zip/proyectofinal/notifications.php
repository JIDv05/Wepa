<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_login();
$user = current_user();

if (isset($_GET['read'])) {
    $pdo->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND user_id=?")
        ->execute([(int)$_GET['read'], $user['id']]);
}

$stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC");
$stmt->execute([$user['id']]);
$notifs = $stmt->fetchAll(PDO::FETCH_ASSOC);

include __DIR__ . '/includes/header.php';
include __DIR__ . '/includes/sidebar.php';
?>
<div class="app-card p-3">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="h5 mb-0">Notificaciones</h2>
  </div>
  <?php if (!$notifs): ?>
    <p class="text-secondary small mb-0">No tienes notificaciones por el momento.</p>
  <?php else: ?>
    <div class="list-group list-group-flush">
      <?php foreach ($notifs as $n): ?>
        <div class="list-group-item bg-transparent border-secondary-subtle text-light d-flex justify-content-between align-items-start">
          <div>
            <div class="fw-semibold"><?php echo htmlspecialchars($n['title']); ?></div>
            <div class="small text-secondary"><?php echo nl2br(htmlspecialchars($n['message'])); ?></div>
            <div class="small text-secondary mt-1"><?php echo htmlspecialchars($n['created_at']); ?></div>
          </div>
          <div class="ms-3 text-end">
            <?php if (!$n['is_read']): ?>
              <a href="?read=<?php echo $n['id']; ?>" class="badge bg-info text-dark text-decoration-none">Marcar como leída</a>
            <?php else: ?>
              <span class="badge bg-secondary">Leída</span>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/includes/footer.php'; ?>
